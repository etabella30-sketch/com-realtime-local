from sqlconfig import execute_query
from common import transform_data,transform_data_highlights
from file import read_file, save_json_file, parse_text, convert_to_codefeed_data,create_folder_if_not_exists,generate_paths
from issuetransfer import transfer_issue_detail
from highlighttransfer import transfer_r_highlights
import sys








missing_args = []
if len(sys.argv) < 2:
    missing_args.append("sessionid")
if len(sys.argv) < 3:
    missing_args.append("draft_path")
if len(sys.argv) < 4:
    missing_args.append("trans_script_path_save")

if missing_args:
    print(f"Error: Missing arguments: {', '.join(missing_args)}")
    sys.exit(1)

# Get command-line arguments
sessionid = int(sys.argv[1])
draft_path = sys.argv[2]
trans_script_path_save = sys.argv[3]

# /var/www/html/api/assets/pythons/annot-transfer/start.py 84 /var/www/html/api/assets/doc/case282/s_84.TXT /var/www/html/api/assets/realtime-transcripts/

# sessionid = 84   #get the param from the the sys.argv; nSesid
# draft_path = '/var/www/html/api/assets/doc/case282/s_84.TXT' #get the param from the the psys.argv filePath
# trans_script_path_save = '/var/www/html/api/assets/realtime-transcripts/s_84.json' # save the file to path  #REALTIME_PATH

save_Data=False
folder_path = f'./{sessionid}'
create_folder_if_not_exists(folder_path)



paths = generate_paths(folder_path,sessionid,trans_script_path_save)

annotations = execute_query('et_realtime_get_annotation_by_session', f'{{"nSessionid":{sessionid}}}')
save_json_file(paths['raw_annotation_file'], annotations)
#print(annotations)
edited_text = None
edited_lines = None
search_data = None
codefeed_data_list = None
edited_text = read_file(draft_path)    

try:
    edited_lines = parse_text(edited_text)    
except Exception as e:
    print(f"Error reading draft file: {e}")
    edited_text = ''
    exit()


search_data = edited_lines
save_json_file(paths['line_path'], edited_lines)

try:
    codefeed_data_list = convert_to_codefeed_data(edited_lines)
except Exception as e:
    print(f"Error converting to codefeed data: {e}")
    codefeed_data_list = []
    exit()

save_json_file(paths['trans_script_path'], codefeed_data_list)

save_json_file( paths['trans_script_path_save'], codefeed_data_list)

print('FILE_SAVED_TO_PATH')

try:
    annotation_data = transform_data(annotations)
    save_json_file(paths['annotation_file'], annotation_data)
except Exception as e:
    print(f"Error transforming annotation data: {e}")
    annotation_data = []


if len(annotation_data) == 0:
    print("No annotations found. Exiting...")
else:
    transfer_issue_detail(annotation_data, search_data, paths, save_Data)    







######################### Start Highlights Transfer #############################

folder_path = f'./{sessionid}_H'
create_folder_if_not_exists(folder_path)
save_Data=False
paths = generate_paths(folder_path,sessionid,trans_script_path_save)


annotations = execute_query('et_realtime_get_RHighlights_by_session', f'{{"nSessionid":{sessionid}}}')
#print(annotations)
save_json_file(paths['raw_annotation_file'], annotations)


try:
    annotation_data = transform_data_highlights(annotations)
    save_json_file(paths['annotation_file'], annotation_data)
except Exception as e:
    print(f"Error transforming annotation data: {e}")
    annotation_data = []


if len(annotation_data) == 0:
    print("No annotations found. Exiting...")
else:
    transfer_r_highlights(annotation_data, search_data, paths, save_Data)








